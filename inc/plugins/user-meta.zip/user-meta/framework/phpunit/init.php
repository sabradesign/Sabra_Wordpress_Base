<?php

/*
 * Include wp-load.php for test class.
 */

/*$dirName = dirname( __FILE__ );

// Determine wp-load path and include
$found = false;$i=0;
while( ( !$found ) && ( $i < 10 ) ){
    $i++;
    $dirName .= '/..';
    if( file_exists( $dirName . '/wp-load.php' ) ){
        $found = true;
        define( 'WP_USE_THEMES', false );
        require( $dirName . '/wp-load.php' );
    }    
}*/

?>
